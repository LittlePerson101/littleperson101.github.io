package io.github.littleperson101.pokeloader.client.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.littleperson101.pokeloader.config.PokeloaderConfig;
import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_425.class)
public class LoadingOverlayMixin {

    @Shadow
    @Final
    private class_310 minecraft;

    @Unique
    private static final long ANIMATION_DURATION_MS = 1000;
    @Unique
    private long startTime = -1;
    @Unique
    private long fadeStartTime = -1;
    @Unique
    private boolean soundPlayed = false;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void drawProceduralPokeball(class_332 guiGraphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!PokeloaderConfig.getInstance().enableCustomLoadingScreen) {
            return;
        }

        if (startTime == -1) {
            startTime = System.currentTimeMillis();
        }

        // 1. Calculate timing
        long elapsed = System.currentTimeMillis() - startTime;
        long totalWaitTime = ANIMATION_DURATION_MS + PokeloaderConfig.getInstance().lingerTimeMs;

        // progress stays at 1.0 during the linger phase
        double progress = Math.min(1.0, (double) elapsed / ANIMATION_DURATION_MS);

        // 2. Logic: Handle fade start after animation + linger
        boolean isGameLoaded = this.minecraft.field_1755 != null;
        if (isGameLoaded && elapsed >= totalWaitTime && fadeStartTime == -1) {
            fadeStartTime = System.currentTimeMillis();
        }

        // 3. Calculate alpha for fading
        float alpha = 1.0f;
        if (fadeStartTime != -1) {
            long fadeElapsed = System.currentTimeMillis() - fadeStartTime;
            alpha = 1.0f - Math.min(1.0f, (float) fadeElapsed / 2000.0f);
            if (alpha <= 0.0f) {
                return;
            }
        }

        // 4. Handle Sound
        if (PokeloaderConfig.getInstance().playCatchSound && progress >= 0.9 && !soundPlayed) {
            try {
                class_2960 soundRegistryLocation = class_2960.method_60655("pokeloader", "pokeball_catch");
                class_3414 pokeballSound = class_3414.method_47908(soundRegistryLocation);
                this.minecraft.method_1483().method_4873(class_1109.method_4758(pokeballSound, 1.0F));
            } catch (Exception e) {
                e.printStackTrace();
            }
            soundPlayed = true;
        }

        // 5. Drawing
// 5. Drawing (updated with inversion logic)
// 5. Drawing
        int width = guiGraphics.method_51421();
        int height = guiGraphics.method_51443();
        int centerX = width / 2;
        int centerY = height / 2;
        int radius = 50;
        int alphaBits = ((int) (alpha * 255)) << 24;

        // Config check
        boolean invert = PokeloaderConfig.getInstance().invertColors;

        // Helper to handle color inversion
        // This inverts the RGB part (0x00FFFFFF) and leaves the alpha untouched
        java.util.function.IntUnaryOperator applyInvert = c -> invert ? (~c & 0x00FFFFFF) : (c & 0x00FFFFFF);

        // Background
        guiGraphics.method_25294(0, 0, width, height, alphaBits | applyInvert.applyAsInt(0x121212));

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        // White part (becomes Black if inverted)
        guiGraphics.method_25294(centerX - radius, centerY, centerX + radius, centerY + radius, alphaBits | applyInvert.applyAsInt(0xFFFFFF));

        // Red part (becomes Cyan if inverted)
        int upperOffset = (int) ((1.0 - progress) * 40);
        guiGraphics.method_25294(centerX - radius, centerY - radius - upperOffset, centerX + radius, centerY - upperOffset, alphaBits | applyInvert.applyAsInt(0xE63946));

        // Trim part
        guiGraphics.method_25294(centerX - radius - 2, centerY - 3, centerX + radius + 2, centerY + 3, alphaBits | applyInvert.applyAsInt(0x2B2B2B));
        guiGraphics.method_25294(centerX - 14, centerY - 14, centerX + 14, centerY + 14, alphaBits | applyInvert.applyAsInt(0x2B2B2B));

        // Core
        int coreColor = (progress < 1.0) ? 0x888888 : PokeloaderConfig.getInstance().orbColor;
        guiGraphics.method_25294(centerX - 8, centerY - 8, centerX + 8, centerY + 8, alphaBits | applyInvert.applyAsInt(coreColor));

        RenderSystem.disableBlend();
        ci.cancel();
    }
}