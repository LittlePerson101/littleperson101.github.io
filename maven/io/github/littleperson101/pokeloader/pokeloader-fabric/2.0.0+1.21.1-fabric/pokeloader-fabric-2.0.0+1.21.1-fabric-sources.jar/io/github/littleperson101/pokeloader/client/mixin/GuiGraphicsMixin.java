package io.github.littleperson101.pokeloader.client.mixin;

import io.github.littleperson101.pokeloader.config.PokeloaderConfig;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_332.class)
public class GuiGraphicsMixin {
    @Inject(method = "blitSprite(Lnet/minecraft/resources/ResourceLocation;IIII)V", at = @At("HEAD"), cancellable = true)
    private void dropMojangLogoDraws(class_2960 resourceLocation, int x, int y, int width, int height, CallbackInfo ci) {
        if (!PokeloaderConfig.getInstance().enableCustomLoadingScreen) {
            return;
        }
        if (resourceLocation != null && (resourceLocation.method_12832().contains("mojang") || resourceLocation.method_12832().contains("logo"))) {
            ci.cancel();
        }
    }
}
